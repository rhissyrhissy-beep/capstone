-- ============================================================================
-- WheelSync — Supabase Schema
-- Run this once in the Supabase SQL Editor (Project > SQL Editor > New query)
-- ============================================================================

-- ---------- Enums ----------
create type user_role as enum ('admin', 'staff', 'customer');
create type vehicle_status as enum ('available', 'rented', 'maintenance');
create type booking_status as enum ('pending', 'accepted', 'rejected', 'ongoing', 'completed', 'cancelled');
create type inspection_type as enum ('pre_rental', 'post_rental');

-- ---------- Tables ----------

-- One row per auth.users row. Created automatically by the trigger below.
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text,
  role user_role not null default 'customer',
  is_blacklisted boolean not null default false,
  created_by uuid references profiles(id), -- set when admin creates a staff account
  created_at timestamptz not null default now()
);

create table vehicles (
  id uuid primary key default gen_random_uuid(),
  make text not null,
  model text not null,
  year int not null,
  plate_number text not null unique,
  category text not null default 'sedan',
  daily_rate numeric(10,2) not null,
  status vehicle_status not null default 'available',
  image_url text,
  created_at timestamptz not null default now()
);

create table bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references profiles(id) on delete cascade,
  vehicle_id uuid not null references vehicles(id),
  assigned_staff_id uuid references profiles(id),
  start_date date not null,
  end_date date not null,
  pickup_location text,
  status booking_status not null default 'pending',
  total_amount numeric(10,2),
  notes text,
  decided_by uuid references profiles(id),
  decided_at timestamptz,
  created_at timestamptz not null default now()
);

create table inspections (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  staff_id uuid not null references profiles(id),
  type inspection_type not null,
  checklist jsonb not null default '{}'::jsonb,
  damage_notes text,
  odometer_reading int,
  fuel_level text,
  photos jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  body text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Auto-create a profile row whenever a new auth user signs up ----------
-- The role + full_name are passed in from the client via signUp's `options.data`.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Unnamed User'),
    new.email,
    new.raw_user_meta_data->>'phone',
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'customer')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------- Helper: is the current user an admin? ----------
create or replace function public.is_admin()
returns boolean
language sql
security definer set search_path = public
as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.is_staff()
returns boolean
language sql
security definer set search_path = public
as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'staff'
  );
$$;

-- ---------- Row Level Security ----------
alter table profiles enable row level security;
alter table vehicles enable row level security;
alter table bookings enable row level security;
alter table inspections enable row level security;
alter table notifications enable row level security;

-- profiles
create policy "profiles: read own or admin reads all" on profiles
  for select using (id = auth.uid() or public.is_admin());

create policy "profiles: user updates own" on profiles
  for update using (id = auth.uid() or public.is_admin());

create policy "profiles: self insert on signup" on profiles
  for insert with check (id = auth.uid());

-- vehicles — everyone signed in can browse; only admin manages
create policy "vehicles: any authenticated user can read" on vehicles
  for select using (auth.role() = 'authenticated');

create policy "vehicles: admin manages" on vehicles
  for all using (public.is_admin()) with check (public.is_admin());

-- bookings
create policy "bookings: customer reads own" on bookings
  for select using (
    customer_id = auth.uid()
    or assigned_staff_id = auth.uid()
    or public.is_admin()
  );

create policy "bookings: customer creates own" on bookings
  for insert with check (customer_id = auth.uid());

create policy "bookings: admin updates any, staff updates assigned" on bookings
  for update using (
    public.is_admin()
    or assigned_staff_id = auth.uid()
  );

-- inspections
create policy "inspections: staff/admin read relevant, customer reads own booking's" on inspections
  for select using (
    public.is_admin()
    or staff_id = auth.uid()
    or exists (select 1 from bookings b where b.id = booking_id and b.customer_id = auth.uid())
  );

create policy "inspections: staff creates for assigned booking" on inspections
  for insert with check (
    staff_id = auth.uid()
    and exists (select 1 from bookings b where b.id = booking_id and b.assigned_staff_id = auth.uid())
  );

-- notifications
create policy "notifications: read own" on notifications
  for select using (user_id = auth.uid());

create policy "notifications: system/admin insert" on notifications
  for insert with check (true);

create policy "notifications: mark own read" on notifications
  for update using (user_id = auth.uid());

-- ---------- Realtime ----------
alter publication supabase_realtime add table bookings;
alter publication supabase_realtime add table notifications;

-- ---------- Seed a few vehicles so the apps have something to show ----------
insert into vehicles (make, model, year, plate_number, category, daily_rate, status, image_url) values
  ('Toyota', 'Vios', 2023, 'CDO-1001', 'sedan', 1800, 'available', null),
  ('Mitsubishi', 'Xpander', 2022, 'CDO-1002', 'suv', 2500, 'available', null),
  ('Honda', 'City', 2024, 'CDO-1003', 'sedan', 2000, 'available', null),
  ('Toyota', 'Hiace', 2021, 'CDO-1004', 'van', 4500, 'available', null);
