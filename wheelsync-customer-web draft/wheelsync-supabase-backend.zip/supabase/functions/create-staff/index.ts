// supabase/functions/create-staff/index.ts
//
// Deploy with:  supabase functions deploy create-staff
// Lets an ADMIN create a staff account from the Admin web app without the
// browser ever seeing the service-role key, and without switching the
// admin's own logged-in session (which is what would happen if the admin
// app called supabase.auth.signUp directly).
//
// Call it from the client as:
//   supabase.functions.invoke('create-staff', { body: { full_name, email, phone, password } })

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  };
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing Authorization header" }), {
        status: 401,
        headers: cors,
      });
    }

    // Client bound to the CALLER's JWT — used only to verify the caller is an admin.
    const callerClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await callerClient.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401, headers: cors });
    }

    const { data: callerProfile } = await callerClient
      .from("profiles")
      .select("role")
      .eq("id", userData.user.id)
      .single();

    if (callerProfile?.role !== "admin") {
      return new Response(JSON.stringify({ error: "Only an admin can create staff accounts" }), {
        status: 403,
        headers: cors,
      });
    }

    const { full_name, email, phone, password } = await req.json();
    if (!full_name || !email || !password) {
      return new Response(JSON.stringify({ error: "full_name, email and password are required" }), {
        status: 400,
        headers: cors,
      });
    }

    // Admin client — allowed to create users directly (bypasses email confirmation).
    const adminClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const { data: created, error: createErr } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name, phone, role: "staff" },
    });

    if (createErr) {
      return new Response(JSON.stringify({ error: createErr.message }), { status: 400, headers: cors });
    }

    // The DB trigger (handle_new_user) already inserted the profile row with role='staff'.
    // Stamp who created it.
    await adminClient
      .from("profiles")
      .update({ created_by: userData.user.id })
      .eq("id", created.user!.id);

    return new Response(JSON.stringify({ user: created.user }), {
      status: 200,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: cors });
  }
});
